#!/bin/bash

unzip main.zip
clear
cd sysd-main
 
chmod +x d.sh k.sh
./d.sh
